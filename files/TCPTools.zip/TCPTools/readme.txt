This TCP tools are originally designed by Michael_ee for esp32 WIFI lessons.

TCPServer.exe run as a TCP server, which can receive multiple clients' data through TCP connection.

TCPClient.exe run as a TCP client, which can connect and send data to one server.

All rights @ Micro-studios

www.micro-studios.com