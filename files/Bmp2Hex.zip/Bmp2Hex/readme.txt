This is Bmp2Hex tool version 1.1, running only on windows.

It will read 24bit bmp image file, convert the bmp data into 16bit (RGB=565) Hex text file.

The result file format will be "xxx.bmp.txt". The "xxx.bmp" means the text file matches which bmp file.

This tool is originally designed for "FPGA Drive SPI TFT LCD".