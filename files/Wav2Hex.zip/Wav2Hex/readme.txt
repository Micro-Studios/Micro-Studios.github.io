This is Wav2Hex tool version 1.0, running only on windows.

It will decode the PCM data from a wave file into one c head file as a data array! 
It is originally designed for an esp32 I2S audio project! 

The result file format will be "xxx.wav.h". 

